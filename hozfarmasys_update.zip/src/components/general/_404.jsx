const _404= ()=>{
    return(
        <div>
    <h1>Not found </h1>
</div>
    );
};

export default _404;
