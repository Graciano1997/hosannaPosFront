import { useTranslation } from "react-i18next";
import CardTitle from "./CardTitle";
import { firstCapitalize } from "../../lib/firstCapitalize";

const Card =({width=200,height=300,info})=>{    

    const {t}=useTranslation();

    return(
         <div style={{height:height,width:width}} className={`grid grid-rows-[50px_auto] bg-white rounded shadow-md`}>
             <CardTitle>
                <h2 className="text-center">{firstCapitalize(info.title)}</h2>
            </CardTitle>
             <div className="flex justify-center items-center">
                <p className={`text-${info.output?'red':'green'}-400 text-3xl`}>{info.description}</p> 
             </div>
        </div>
    );
};

export default Card;
